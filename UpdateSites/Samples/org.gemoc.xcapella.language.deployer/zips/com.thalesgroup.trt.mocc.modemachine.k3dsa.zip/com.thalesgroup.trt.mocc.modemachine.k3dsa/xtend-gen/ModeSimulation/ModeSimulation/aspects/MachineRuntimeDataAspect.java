package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.mode.mode.Mode_;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.MachineRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Aspect(className = MachineRuntimeData.class)
@SuppressWarnings("all")
public class MachineRuntimeDataAspect {
  public static String init(final MachineRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_init(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static Mode_ current(final MachineRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_current(_self_, _self);
    return (com.thalesgroup.trt.mde.vp.mode.mode.Mode_)result;
  }
  
  public static void current(final MachineRuntimeData _self, final Mode_ current) {
    ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectContext.getSelf(_self);
    _privk3_current(_self_, _self,current);
  }
  
  protected static String _privk3_init(final MachineRuntimeDataAspectMachineRuntimeDataAspectProperties _self_, final MachineRuntimeData _self) {
    Class<? extends MachineRuntimeData> _class = _self.getClass();
    String _simpleName = _class.getSimpleName();
    String _plus = ("[" + _simpleName);
    String _plus_1 = (_plus + ":");
    String _name = _self.getName();
    String _plus_2 = (_plus_1 + _name);
    String _plus_3 = (_plus_2 + ".Init()]Initialized ");
    String _name_1 = _self.getName();
    String _plus_4 = (_plus_3 + _name_1);
    return InputOutput.<String>println(_plus_4);
  }
  
  protected static Mode_ _privk3_current(final MachineRuntimeDataAspectMachineRuntimeDataAspectProperties _self_, final MachineRuntimeData _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getCurrent") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (com.thalesgroup.trt.mde.vp.mode.mode.Mode_) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.current;
  }
  
  protected static void _privk3_current(final MachineRuntimeDataAspectMachineRuntimeDataAspectProperties _self_, final MachineRuntimeData _self, final Mode_ current) {
    _self_.current = current; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setCurrent")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, current);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
