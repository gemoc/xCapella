package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.MachineRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class MachineRuntimeDataAspectMachineRuntimeDataAspectContext {
  public final static MachineRuntimeDataAspectMachineRuntimeDataAspectContext INSTANCE = new MachineRuntimeDataAspectMachineRuntimeDataAspectContext();
  
  public static MachineRuntimeDataAspectMachineRuntimeDataAspectProperties getSelf(final MachineRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<MachineRuntimeData, MachineRuntimeDataAspectMachineRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.MachineRuntimeData, ModeSimulation.ModeSimulation.aspects.MachineRuntimeDataAspectMachineRuntimeDataAspectProperties>();
  
  public Map<MachineRuntimeData, MachineRuntimeDataAspectMachineRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
