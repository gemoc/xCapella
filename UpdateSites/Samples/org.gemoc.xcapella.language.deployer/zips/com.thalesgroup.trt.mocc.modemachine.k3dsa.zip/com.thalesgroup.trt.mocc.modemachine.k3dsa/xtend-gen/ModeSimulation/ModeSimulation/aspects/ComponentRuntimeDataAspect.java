package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ComponentRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.polarsys.capella.core.data.cs.Component;

@Aspect(className = ComponentRuntimeData.class)
@SuppressWarnings("all")
public class ComponentRuntimeDataAspect {
  public static String init(final ComponentRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.ComponentRuntimeDataAspectComponentRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_init(_self_, _self);
    return (java.lang.String)result;
  }
  
  protected static String _privk3_init(final ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties _self_, final ComponentRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      Component comp = ((Component) _eContainer);
      Class<? extends Component> _class = comp.getClass();
      String _simpleName = _class.getSimpleName();
      String _plus = ("[" + _simpleName);
      String _plus_1 = (_plus + ":");
      String _name = comp.getName();
      String _plus_2 = (_plus_1 + _name);
      String _plus_3 = (_plus_2 + ".Init()]Initialized ");
      String _name_1 = comp.getName();
      String _plus_4 = (_plus_3 + _name_1);
      _xblockexpression = InputOutput.<String>println(_plus_4);
    }
    return _xblockexpression;
  }
}
