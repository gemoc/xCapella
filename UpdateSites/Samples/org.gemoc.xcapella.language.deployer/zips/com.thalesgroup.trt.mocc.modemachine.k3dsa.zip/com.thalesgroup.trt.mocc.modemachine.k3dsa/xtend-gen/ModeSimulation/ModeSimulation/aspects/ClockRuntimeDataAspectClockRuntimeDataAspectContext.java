package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ClockRuntimeDataAspectClockRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ClockRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class ClockRuntimeDataAspectClockRuntimeDataAspectContext {
  public final static ClockRuntimeDataAspectClockRuntimeDataAspectContext INSTANCE = new ClockRuntimeDataAspectClockRuntimeDataAspectContext();
  
  public static ClockRuntimeDataAspectClockRuntimeDataAspectProperties getSelf(final ClockRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.ClockRuntimeDataAspectClockRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ClockRuntimeData, ClockRuntimeDataAspectClockRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ClockRuntimeData, ModeSimulation.ModeSimulation.aspects.ClockRuntimeDataAspectClockRuntimeDataAspectProperties>();
  
  public Map<ClockRuntimeData, ClockRuntimeDataAspectClockRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
