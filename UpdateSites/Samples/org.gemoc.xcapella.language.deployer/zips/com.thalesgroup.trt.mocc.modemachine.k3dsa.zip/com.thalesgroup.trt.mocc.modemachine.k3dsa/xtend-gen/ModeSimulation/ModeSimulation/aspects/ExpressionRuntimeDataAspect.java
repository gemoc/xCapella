package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.Expression;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ExpressionRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.ecore.EObject;

@Aspect(className = ExpressionRuntimeData.class)
@SuppressWarnings("all")
public class ExpressionRuntimeDataAspect {
  public static boolean evaluate(final ExpressionRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.ExpressionRuntimeDataAspectExpressionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_evaluate(_self_, _self);
    return (boolean)result;
  }
  
  protected static boolean _privk3_evaluate(final ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties _self_, final ExpressionRuntimeData _self) {
    EObject _eContainer = _self.eContainer();
    Expression expr = ((Expression) _eContainer);
    return true;
  }
}
