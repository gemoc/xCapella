package ModeSimulation.ModeSimulation.aspects;

import com.thalesgroup.trt.mde.vp.mode.mode.Mode_;

@SuppressWarnings("all")
public class MachineRuntimeDataAspectMachineRuntimeDataAspectProperties {
  public Mode_ current;
}
