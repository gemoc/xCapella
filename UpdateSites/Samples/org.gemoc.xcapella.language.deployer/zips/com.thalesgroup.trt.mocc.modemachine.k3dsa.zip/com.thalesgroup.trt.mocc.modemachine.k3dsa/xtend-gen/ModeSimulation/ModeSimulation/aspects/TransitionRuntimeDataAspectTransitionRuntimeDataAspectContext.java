package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.TransitionRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class TransitionRuntimeDataAspectTransitionRuntimeDataAspectContext {
  public final static TransitionRuntimeDataAspectTransitionRuntimeDataAspectContext INSTANCE = new TransitionRuntimeDataAspectTransitionRuntimeDataAspectContext();
  
  public static TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties getSelf(final TransitionRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<TransitionRuntimeData, TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.TransitionRuntimeData, ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties>();
  
  public Map<TransitionRuntimeData, TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
