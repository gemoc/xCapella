package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.NumericExpressionAspectNumericExpressionAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.NumericExpression;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = NumericExpression.class)
@SuppressWarnings("all")
public class NumericExpressionAspect {
  public static double evaluate(final NumericExpression _self) {
    ModeSimulation.ModeSimulation.aspects.NumericExpressionAspectNumericExpressionAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.NumericExpressionAspectNumericExpressionAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_evaluate(_self_, _self);
    return (double)result;
  }
  
  protected static double _privk3_evaluate(final NumericExpressionAspectNumericExpressionAspectProperties _self_, final NumericExpression _self) {
    return 0.0;
  }
}
