package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression;
import java.util.Map;

@SuppressWarnings("all")
public class BooleanExpressionAspectBooleanExpressionAspectContext {
  public final static BooleanExpressionAspectBooleanExpressionAspectContext INSTANCE = new BooleanExpressionAspectBooleanExpressionAspectContext();
  
  public static BooleanExpressionAspectBooleanExpressionAspectProperties getSelf(final BooleanExpression _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<BooleanExpression, BooleanExpressionAspectBooleanExpressionAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression, ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectProperties>();
  
  public Map<BooleanExpression, BooleanExpressionAspectBooleanExpressionAspectProperties> getMap() {
    return map;
  }
}
