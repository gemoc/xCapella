package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspect;
import ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.al.al.Action;
import com.thalesgroup.trt.mde.vp.mode.mode.AbstractMode;
import com.thalesgroup.trt.mde.vp.mode.mode.ModeMachine;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ActionRuntimeData;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.MachineRuntimeData;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ModeRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.polarsys.kitalpha.emde.model.ElementExtension;

@Aspect(className = ModeRuntimeData.class)
@SuppressWarnings("all")
public class ModeRuntimeDataAspect {
  public static String onEnter(final ModeRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_onEnter(_self_, _self);
    return (java.lang.String)result;
  }
  
  private static void runAction(final ModeRuntimeData _self, final Action a) {
    ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectContext.getSelf(_self);
    _privk3_runAction(_self_, _self,a);
  }
  
  public static String onLeave(final ModeRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_onLeave(_self_, _self);
    return (java.lang.String)result;
  }
  
  protected static String _privk3_onEnter(final ModeRuntimeDataAspectModeRuntimeDataAspectProperties _self_, final ModeRuntimeData _self) {
    EObject _eContainer = _self.eContainer();
    AbstractMode mode = ((AbstractMode) _eContainer);
    EObject _eContainer_1 = mode.eContainer();
    ModeMachine machine = ((ModeMachine) _eContainer_1);
    EList<ElementExtension> _ownedExtensions = machine.getOwnedExtensions();
    for (final ElementExtension ext : _ownedExtensions) {
      if ((ext instanceof MachineRuntimeData)) {
        ((MachineRuntimeData) ext).setCurrent(mode);
      }
    }
    return "";
  }
  
  protected static void _privk3_runAction(final ModeRuntimeDataAspectModeRuntimeDataAspectProperties _self_, final ModeRuntimeData _self, final Action a) {
    EList<EObject> _eContents = a.eContents();
    ActionRuntimeData act = ((ActionRuntimeData) _eContents);
    ActionRuntimeDataAspect.evaluate(act);
  }
  
  protected static String _privk3_onLeave(final ModeRuntimeDataAspectModeRuntimeDataAspectProperties _self_, final ModeRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      AbstractMode mode = ((AbstractMode) _eContainer);
      EObject _eContainer_1 = mode.eContainer();
      ModeMachine machine = ((ModeMachine) _eContainer_1);
      EList<ElementExtension> _ownedExtensions = machine.getOwnedExtensions();
      for (final ElementExtension ext : _ownedExtensions) {
        if ((ext instanceof MachineRuntimeData)) {
          ((MachineRuntimeData) ext).setCurrent(null);
        }
      }
      Class<? extends AbstractMode> _class = mode.getClass();
      String _simpleName = _class.getSimpleName();
      String _plus = ("[" + _simpleName);
      String _plus_1 = (_plus + ":");
      String _name = mode.getName();
      String _plus_2 = (_plus_1 + _name);
      String _plus_3 = (_plus_2 + ".onLeave()]Leaving ");
      String _name_1 = mode.getName();
      String _plus_4 = (_plus_3 + _name_1);
      _xblockexpression = InputOutput.<String>println(_plus_4);
    }
    return _xblockexpression;
  }
}
