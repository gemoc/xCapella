package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect;
import ModeSimulation.ModeSimulation.aspects.BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectProperties;
import com.google.common.base.Objects;
import com.thalesgroup.trt.mde.vp.expression.expression.BooleanUnaryExpression;
import com.thalesgroup.trt.mde.vp.expression.expression.BooleanUnaryOperator;
import com.thalesgroup.trt.mde.vp.expression.expression.Variable;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;
import org.polarsys.capella.common.data.modellingcore.ValueSpecification;
import org.polarsys.capella.core.data.information.datavalue.LiteralBooleanValue;

@Aspect(className = BooleanUnaryExpression.class)
@SuppressWarnings("all")
public class BooleanUnaryExpressionAspect extends BooleanExpressionAspect {
  @OverrideAspectMethod
  public static boolean evaluate(final BooleanUnaryExpression _self) {
    ModeSimulation.ModeSimulation.aspects.BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectContext.getSelf(_self);
    Object result = null;
     if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanUnaryExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanUnaryExpressionAspect._privk3_evaluate(_self_, (com.thalesgroup.trt.mde.vp.expression.expression.BooleanUnaryExpression)_self);
    } else  if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect.evaluate((com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
    return (boolean)result;
  }
  
  private static boolean super_evaluate(final BooleanUnaryExpression _self) {
    ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectContext.getSelf(_self);
    return  ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect._privk3_evaluate(_self_, _self);
  }
  
  protected static boolean _privk3_evaluate(final BooleanUnaryExpressionAspectBooleanUnaryExpressionAspectProperties _self_, final BooleanUnaryExpression _self) {
    Variable _operand = _self.getOperand();
    ValueSpecification _currentValue = _operand.getCurrentValue();
    boolean res = ((LiteralBooleanValue) _currentValue).isValue();
    BooleanUnaryOperator _operator = _self.getOperator();
    boolean _notEquals = (!Objects.equal(_operator, null));
    if (_notEquals) {
      res = (!res);
    }
    return res;
  }
}
