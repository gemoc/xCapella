package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.EventRuntimeDataAspectEventRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.EventRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.polarsys.capella.common.data.behavior.AbstractEvent;

@Aspect(className = EventRuntimeData.class)
@SuppressWarnings("all")
public class EventRuntimeDataAspect {
  public static String occurs(final EventRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.EventRuntimeDataAspectEventRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.EventRuntimeDataAspectEventRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_occurs(_self_, _self);
    return (java.lang.String)result;
  }
  
  protected static String _privk3_occurs(final EventRuntimeDataAspectEventRuntimeDataAspectProperties _self_, final EventRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      AbstractEvent myEv = ((AbstractEvent) _eContainer);
      Class<? extends AbstractEvent> _class = myEv.getClass();
      String _simpleName = _class.getSimpleName();
      String _plus = ("[" + _simpleName);
      String _plus_1 = (_plus + ":");
      String _name = myEv.getName();
      String _plus_2 = (_plus_1 + _name);
      String _plus_3 = (_plus_2 + ".occurs()]  Occurred ");
      _xblockexpression = InputOutput.<String>println(_plus_3);
    }
    return _xblockexpression;
  }
}
