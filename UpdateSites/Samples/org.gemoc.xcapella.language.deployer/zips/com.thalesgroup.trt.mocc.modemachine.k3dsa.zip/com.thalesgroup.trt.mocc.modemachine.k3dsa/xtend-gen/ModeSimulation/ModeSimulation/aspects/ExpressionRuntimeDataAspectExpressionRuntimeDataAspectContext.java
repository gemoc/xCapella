package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ExpressionRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class ExpressionRuntimeDataAspectExpressionRuntimeDataAspectContext {
  public final static ExpressionRuntimeDataAspectExpressionRuntimeDataAspectContext INSTANCE = new ExpressionRuntimeDataAspectExpressionRuntimeDataAspectContext();
  
  public static ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties getSelf(final ExpressionRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ExpressionRuntimeData, ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ExpressionRuntimeData, ModeSimulation.ModeSimulation.aspects.ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties>();
  
  public Map<ExpressionRuntimeData, ExpressionRuntimeDataAspectExpressionRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
