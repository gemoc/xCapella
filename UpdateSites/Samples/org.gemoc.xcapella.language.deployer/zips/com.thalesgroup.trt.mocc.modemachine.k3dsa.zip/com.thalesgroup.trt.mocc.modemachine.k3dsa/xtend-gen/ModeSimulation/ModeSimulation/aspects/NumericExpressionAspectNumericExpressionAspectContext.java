package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.NumericExpressionAspectNumericExpressionAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.NumericExpression;
import java.util.Map;

@SuppressWarnings("all")
public class NumericExpressionAspectNumericExpressionAspectContext {
  public final static NumericExpressionAspectNumericExpressionAspectContext INSTANCE = new NumericExpressionAspectNumericExpressionAspectContext();
  
  public static NumericExpressionAspectNumericExpressionAspectProperties getSelf(final NumericExpression _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.NumericExpressionAspectNumericExpressionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<NumericExpression, NumericExpressionAspectNumericExpressionAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.expression.expression.NumericExpression, ModeSimulation.ModeSimulation.aspects.NumericExpressionAspectNumericExpressionAspectProperties>();
  
  public Map<NumericExpression, NumericExpressionAspectNumericExpressionAspectProperties> getMap() {
    return map;
  }
}
