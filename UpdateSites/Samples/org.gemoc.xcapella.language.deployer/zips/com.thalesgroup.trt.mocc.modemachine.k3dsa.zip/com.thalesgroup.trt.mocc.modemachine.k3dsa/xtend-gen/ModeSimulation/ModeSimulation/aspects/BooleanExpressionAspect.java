package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = BooleanExpression.class)
@SuppressWarnings("all")
public class BooleanExpressionAspect {
  public static boolean evaluate(final BooleanExpression _self) {
    ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectContext.getSelf(_self);
    Object result = null;
     if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.NumericComparisonExpression){
    result = ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspect.evaluate((com.thalesgroup.trt.mde.vp.expression.expression.NumericComparisonExpression)_self);
    } else  if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanBinaryExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanBinaryExpressionAspect.evaluate((com.thalesgroup.trt.mde.vp.expression.expression.BooleanBinaryExpression)_self);
    } else  if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanUnaryExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanUnaryExpressionAspect.evaluate((com.thalesgroup.trt.mde.vp.expression.expression.BooleanUnaryExpression)_self);
    } else  if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect._privk3_evaluate(_self_, (com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
    return (boolean)result;
  }
  
  protected static boolean _privk3_evaluate(final BooleanExpressionAspectBooleanExpressionAspectProperties _self_, final BooleanExpression _self) {
    return true;
  }
}
