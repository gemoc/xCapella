package ModeSimulation.ModeSimulation.aspects;

@SuppressWarnings("all")
public class ClockRuntimeDataAspectClockRuntimeDataAspectProperties {
  public int numberOfTicks;
}
