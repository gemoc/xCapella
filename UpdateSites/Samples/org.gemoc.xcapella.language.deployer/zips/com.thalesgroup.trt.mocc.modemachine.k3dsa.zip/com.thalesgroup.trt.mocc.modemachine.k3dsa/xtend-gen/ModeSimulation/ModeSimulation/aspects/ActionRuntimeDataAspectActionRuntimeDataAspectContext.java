package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspectActionRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ActionRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class ActionRuntimeDataAspectActionRuntimeDataAspectContext {
  public final static ActionRuntimeDataAspectActionRuntimeDataAspectContext INSTANCE = new ActionRuntimeDataAspectActionRuntimeDataAspectContext();
  
  public static ActionRuntimeDataAspectActionRuntimeDataAspectProperties getSelf(final ActionRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspectActionRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ActionRuntimeData, ActionRuntimeDataAspectActionRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ActionRuntimeData, ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspectActionRuntimeDataAspectProperties>();
  
  public Map<ActionRuntimeData, ActionRuntimeDataAspectActionRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
