package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.EventRuntimeDataAspectEventRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.EventRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class EventRuntimeDataAspectEventRuntimeDataAspectContext {
  public final static EventRuntimeDataAspectEventRuntimeDataAspectContext INSTANCE = new EventRuntimeDataAspectEventRuntimeDataAspectContext();
  
  public static EventRuntimeDataAspectEventRuntimeDataAspectProperties getSelf(final EventRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.EventRuntimeDataAspectEventRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<EventRuntimeData, EventRuntimeDataAspectEventRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.EventRuntimeData, ModeSimulation.ModeSimulation.aspects.EventRuntimeDataAspectEventRuntimeDataAspectProperties>();
  
  public Map<EventRuntimeData, EventRuntimeDataAspectEventRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
