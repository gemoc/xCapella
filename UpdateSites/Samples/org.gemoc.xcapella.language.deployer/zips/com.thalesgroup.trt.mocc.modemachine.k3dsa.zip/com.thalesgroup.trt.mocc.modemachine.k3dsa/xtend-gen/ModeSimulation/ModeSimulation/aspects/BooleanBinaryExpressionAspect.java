package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectProperties;
import ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect;
import com.google.common.base.Objects;
import com.thalesgroup.trt.mde.vp.expression.expression.BooleanBinaryExpression;
import com.thalesgroup.trt.mde.vp.expression.expression.BooleanBinaryOperator;
import com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.OverrideAspectMethod;

@Aspect(className = BooleanBinaryExpression.class)
@SuppressWarnings("all")
public class BooleanBinaryExpressionAspect extends BooleanExpressionAspect {
  @OverrideAspectMethod
  public static boolean evaluate(final BooleanBinaryExpression _self) {
    ModeSimulation.ModeSimulation.aspects.BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectContext.getSelf(_self);
    Object result = null;
     if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanBinaryExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanBinaryExpressionAspect._privk3_evaluate(_self_, (com.thalesgroup.trt.mde.vp.expression.expression.BooleanBinaryExpression)_self);
    } else  if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect.evaluate((com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
    return (boolean)result;
  }
  
  private static boolean super_evaluate(final BooleanBinaryExpression _self) {
    ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspectBooleanExpressionAspectContext.getSelf(_self);
    return  ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect._privk3_evaluate(_self_, _self);
  }
  
  protected static boolean _privk3_evaluate(final BooleanBinaryExpressionAspectBooleanBinaryExpressionAspectProperties _self_, final BooleanBinaryExpression _self) {
    boolean res = false;
    BooleanBinaryOperator _operator = _self.getOperator();
    boolean _matched = false;
    if (!_matched) {
      if (Objects.equal(_operator, BooleanBinaryOperator.AND_VALUE)) {
        _matched=true;
        boolean _and = false;
        BooleanExpression _operand1 = _self.getOperand1();
        boolean _evaluate = BooleanExpressionAspect.evaluate(_operand1);
        if (!_evaluate) {
          _and = false;
        } else {
          BooleanExpression _operand2 = _self.getOperand2();
          boolean _evaluate_1 = BooleanExpressionAspect.evaluate(_operand2);
          _and = _evaluate_1;
        }
        res = _and;
      }
    }
    if (!_matched) {
      if (Objects.equal(_operator, BooleanBinaryOperator.OR_VALUE)) {
        _matched=true;
        boolean _or = false;
        BooleanExpression _operand1_1 = _self.getOperand1();
        boolean _evaluate_2 = BooleanExpressionAspect.evaluate(_operand1_1);
        if (_evaluate_2) {
          _or = true;
        } else {
          BooleanExpression _operand2_1 = _self.getOperand2();
          boolean _evaluate_3 = BooleanExpressionAspect.evaluate(_operand2_1);
          _or = _evaluate_3;
        }
        res = _or;
      }
    }
    return res;
  }
}
