package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspectActionRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.al.al.Action;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ActionRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.ecore.EObject;

@Aspect(className = ActionRuntimeData.class)
@SuppressWarnings("all")
public class ActionRuntimeDataAspect {
  public static String evaluate(final ActionRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspectActionRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspectActionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_evaluate(_self_, _self);
    return (java.lang.String)result;
  }
  
  protected static String _privk3_evaluate(final ActionRuntimeDataAspectActionRuntimeDataAspectProperties _self_, final ActionRuntimeData _self) {
    EObject _eContainer = _self.eContainer();
    Action theAction = ((Action) _eContainer);
    String _name = theAction.getName();
    return (_name + "executed");
  }
}
