package ModeSimulation.ModeSimulation.aspects;

@SuppressWarnings("all")
public class ActionRuntimeDataAspectActionRuntimeDataAspectProperties {
}
