package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.NumericComparisonExpression;
import java.util.Map;

@SuppressWarnings("all")
public class NumericComparisonExpressionAspectNumericComparisonExpressionAspectContext {
  public final static NumericComparisonExpressionAspectNumericComparisonExpressionAspectContext INSTANCE = new NumericComparisonExpressionAspectNumericComparisonExpressionAspectContext();
  
  public static NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties getSelf(final NumericComparisonExpression _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<NumericComparisonExpression, NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.expression.expression.NumericComparisonExpression, ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties>();
  
  public Map<NumericComparisonExpression, NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties> getMap() {
    return map;
  }
}
