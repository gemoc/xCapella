package ModeSimulation.ModeSimulation.aspects;

@SuppressWarnings("all")
public class ModeRuntimeDataAspectModeRuntimeDataAspectProperties {
}
