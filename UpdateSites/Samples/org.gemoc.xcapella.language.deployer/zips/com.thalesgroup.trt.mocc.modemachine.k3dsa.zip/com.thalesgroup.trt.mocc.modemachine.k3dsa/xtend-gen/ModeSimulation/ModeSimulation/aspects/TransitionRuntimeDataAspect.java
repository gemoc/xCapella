package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ActionRuntimeDataAspect;
import ModeSimulation.ModeSimulation.aspects.GuardRuntimeDataAspect;
import ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties;
import com.google.common.base.Objects;
import com.thalesgroup.trt.mde.vp.al.al.Action;
import com.thalesgroup.trt.mde.vp.expression.expression.AbstractGuard;
import com.thalesgroup.trt.mde.vp.mode.mode.Transition;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ActionRuntimeData;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.GuardRuntimeData;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.TransitionRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.polarsys.kitalpha.emde.model.ElementExtension;

@Aspect(className = TransitionRuntimeData.class)
@SuppressWarnings("all")
public class TransitionRuntimeDataAspect {
  public static String reset(final TransitionRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_reset(_self_, _self);
    return (java.lang.String)result;
  }
  
  private static void runAction(final TransitionRuntimeData _self, final Action a) {
    ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectContext.getSelf(_self);
    _privk3_runAction(_self_, _self,a);
  }
  
  public static String fire(final TransitionRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_fire(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static boolean evaluate(final TransitionRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.TransitionRuntimeDataAspectTransitionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_evaluate(_self_, _self);
    return (boolean)result;
  }
  
  protected static String _privk3_reset(final TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_, final TransitionRuntimeData _self) {
    EObject _eContainer = _self.eContainer();
    Transition trans = ((Transition) _eContainer);
    String _name = trans.getName();
    String _plus = ("reset of " + _name);
    InputOutput.<String>println(_plus);
    String _name_1 = trans.getName();
    return ("reset of " + _name_1);
  }
  
  protected static void _privk3_runAction(final TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_, final TransitionRuntimeData _self, final Action a) {
    EList<EObject> _eContents = a.eContents();
    ActionRuntimeData act = ((ActionRuntimeData) _eContents);
    ActionRuntimeDataAspect.evaluate(act);
  }
  
  protected static String _privk3_fire(final TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_, final TransitionRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      Transition trans = ((Transition) _eContainer);
      Class<? extends Transition> _class = trans.getClass();
      String _simpleName = _class.getSimpleName();
      String _plus = ("[" + _simpleName);
      String _plus_1 = (_plus + ":");
      String _name = trans.getName();
      String _plus_2 = (_plus_1 + _name);
      String _plus_3 = (_plus_2 + ".fire()]Fired ");
      String _name_1 = trans.getName();
      String _plus_4 = (_plus_3 + _name_1);
      String _plus_5 = (_plus_4 + " -> ");
      EList<Action> _actions = trans.getActions();
      String _plus_6 = (_plus_5 + _actions);
      _xblockexpression = InputOutput.<String>println(_plus_6);
    }
    return _xblockexpression;
  }
  
  protected static boolean _privk3_evaluate(final TransitionRuntimeDataAspectTransitionRuntimeDataAspectProperties _self_, final TransitionRuntimeData _self) {
    EObject _eContainer = _self.eContainer();
    Transition trans = ((Transition) _eContainer);
    AbstractGuard _guard = trans.getGuard();
    boolean _equals = Objects.equal(_guard, null);
    if (_equals) {
      return true;
    }
    AbstractGuard _guard_1 = trans.getGuard();
    EList<ElementExtension> _ownedExtensions = _guard_1.getOwnedExtensions();
    for (final ElementExtension ext : _ownedExtensions) {
      {
        GuardRuntimeData theGuard = ((GuardRuntimeData) ext);
        return GuardRuntimeDataAspect.evaluate(theGuard);
      }
    }
    return false;
  }
}
