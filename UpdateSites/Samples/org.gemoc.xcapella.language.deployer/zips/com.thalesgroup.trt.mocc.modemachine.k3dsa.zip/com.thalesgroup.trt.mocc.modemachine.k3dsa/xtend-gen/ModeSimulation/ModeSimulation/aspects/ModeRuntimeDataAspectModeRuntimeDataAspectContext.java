package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ModeRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class ModeRuntimeDataAspectModeRuntimeDataAspectContext {
  public final static ModeRuntimeDataAspectModeRuntimeDataAspectContext INSTANCE = new ModeRuntimeDataAspectModeRuntimeDataAspectContext();
  
  public static ModeRuntimeDataAspectModeRuntimeDataAspectProperties getSelf(final ModeRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ModeRuntimeData, ModeRuntimeDataAspectModeRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ModeRuntimeData, ModeSimulation.ModeSimulation.aspects.ModeRuntimeDataAspectModeRuntimeDataAspectProperties>();
  
  public Map<ModeRuntimeData, ModeRuntimeDataAspectModeRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
