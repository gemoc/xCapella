package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.GuardRuntimeDataAspectGuardRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.GuardRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class GuardRuntimeDataAspectGuardRuntimeDataAspectContext {
  public final static GuardRuntimeDataAspectGuardRuntimeDataAspectContext INSTANCE = new GuardRuntimeDataAspectGuardRuntimeDataAspectContext();
  
  public static GuardRuntimeDataAspectGuardRuntimeDataAspectProperties getSelf(final GuardRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.GuardRuntimeDataAspectGuardRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<GuardRuntimeData, GuardRuntimeDataAspectGuardRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.GuardRuntimeData, ModeSimulation.ModeSimulation.aspects.GuardRuntimeDataAspectGuardRuntimeDataAspectProperties>();
  
  public Map<GuardRuntimeData, GuardRuntimeDataAspectGuardRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
