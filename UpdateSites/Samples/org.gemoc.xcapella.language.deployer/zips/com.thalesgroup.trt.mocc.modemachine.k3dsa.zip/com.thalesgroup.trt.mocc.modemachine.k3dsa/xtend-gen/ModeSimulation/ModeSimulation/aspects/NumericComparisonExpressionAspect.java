package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect;
import ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.NumericComparisonExpression;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;

@Aspect(className = NumericComparisonExpression.class)
@SuppressWarnings("all")
public class NumericComparisonExpressionAspect extends BooleanExpressionAspect {
  public static boolean evaluate(final NumericComparisonExpression _self) {
    ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspectNumericComparisonExpressionAspectContext.getSelf(_self);
    Object result = null;
     if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.NumericComparisonExpression){
    result = ModeSimulation.ModeSimulation.aspects.NumericComparisonExpressionAspect._privk3_evaluate(_self_, (com.thalesgroup.trt.mde.vp.expression.expression.NumericComparisonExpression)_self);
    } else  if (_self instanceof com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression){
    result = ModeSimulation.ModeSimulation.aspects.BooleanExpressionAspect.evaluate((com.thalesgroup.trt.mde.vp.expression.expression.BooleanExpression)_self);
    } else  { throw new IllegalArgumentException("Unhandled parameter types: " + java.util.Arrays.<Object>asList(_self).toString()); };
    return (boolean)result;
  }
  
  protected static boolean _privk3_evaluate(final NumericComparisonExpressionAspectNumericComparisonExpressionAspectProperties _self_, final NumericComparisonExpression _self) {
    return true;
  }
}
