package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.GuardRuntimeDataAspectGuardRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.expression.expression.AbstractGuard;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.GuardRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.ecore.EObject;

@Aspect(className = GuardRuntimeData.class)
@SuppressWarnings("all")
public class GuardRuntimeDataAspect {
  public static boolean evaluate(final GuardRuntimeData _self) {
    ModeSimulation.ModeSimulation.aspects.GuardRuntimeDataAspectGuardRuntimeDataAspectProperties _self_ = ModeSimulation.ModeSimulation.aspects.GuardRuntimeDataAspectGuardRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_evaluate(_self_, _self);
    return (boolean)result;
  }
  
  protected static boolean _privk3_evaluate(final GuardRuntimeDataAspectGuardRuntimeDataAspectProperties _self_, final GuardRuntimeData _self) {
    EObject _eContainer = _self.eContainer();
    AbstractGuard theGuard = ((AbstractGuard) _eContainer);
    return true;
  }
}
