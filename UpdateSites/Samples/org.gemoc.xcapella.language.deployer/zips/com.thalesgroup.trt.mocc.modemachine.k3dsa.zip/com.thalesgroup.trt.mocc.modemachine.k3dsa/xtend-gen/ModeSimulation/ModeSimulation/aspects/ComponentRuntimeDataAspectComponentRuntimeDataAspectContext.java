package ModeSimulation.ModeSimulation.aspects;

import ModeSimulation.ModeSimulation.aspects.ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties;
import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ComponentRuntimeData;
import java.util.Map;

@SuppressWarnings("all")
public class ComponentRuntimeDataAspectComponentRuntimeDataAspectContext {
  public final static ComponentRuntimeDataAspectComponentRuntimeDataAspectContext INSTANCE = new ComponentRuntimeDataAspectComponentRuntimeDataAspectContext();
  
  public static ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties getSelf(final ComponentRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new ModeSimulation.ModeSimulation.aspects.ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<ComponentRuntimeData, ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.ComponentRuntimeData, ModeSimulation.ModeSimulation.aspects.ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties>();
  
  public Map<ComponentRuntimeData, ComponentRuntimeDataAspectComponentRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
