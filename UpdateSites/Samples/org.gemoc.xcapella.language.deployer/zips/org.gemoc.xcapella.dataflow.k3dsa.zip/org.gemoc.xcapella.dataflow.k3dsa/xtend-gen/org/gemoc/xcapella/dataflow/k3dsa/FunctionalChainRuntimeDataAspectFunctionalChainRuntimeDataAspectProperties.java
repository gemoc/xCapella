package org.gemoc.xcapella.dataflow.k3dsa;

@SuppressWarnings("all")
public class FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectProperties {
}
