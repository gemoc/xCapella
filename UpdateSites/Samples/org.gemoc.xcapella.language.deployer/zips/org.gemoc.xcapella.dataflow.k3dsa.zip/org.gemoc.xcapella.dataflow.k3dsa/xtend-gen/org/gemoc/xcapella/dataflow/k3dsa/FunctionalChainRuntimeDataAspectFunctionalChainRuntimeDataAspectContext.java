package org.gemoc.xcapella.dataflow.k3dsa;

import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.FunctionalChainRuntimeData;
import java.util.Map;
import org.gemoc.xcapella.dataflow.k3dsa.FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectProperties;

@SuppressWarnings("all")
public class FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectContext {
  public final static FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectContext INSTANCE = new FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectContext();
  
  public static FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectProperties getSelf(final FunctionalChainRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.gemoc.xcapella.dataflow.k3dsa.FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<FunctionalChainRuntimeData, FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.FunctionalChainRuntimeData, org.gemoc.xcapella.dataflow.k3dsa.FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectProperties>();
  
  public Map<FunctionalChainRuntimeData, FunctionalChainRuntimeDataAspectFunctionalChainRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
