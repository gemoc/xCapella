package org.gemoc.xcapella.dataflow.k3dsa;

import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.FunctionRuntimeData;
import java.util.Map;
import org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties;

@SuppressWarnings("all")
public class FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext {
  public final static FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext INSTANCE = new FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext();
  
  public static FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties getSelf(final FunctionRuntimeData _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<FunctionRuntimeData, FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties> map = new java.util.WeakHashMap<com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.FunctionRuntimeData, org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties>();
  
  public Map<FunctionRuntimeData, FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties> getMap() {
    return map;
  }
}
