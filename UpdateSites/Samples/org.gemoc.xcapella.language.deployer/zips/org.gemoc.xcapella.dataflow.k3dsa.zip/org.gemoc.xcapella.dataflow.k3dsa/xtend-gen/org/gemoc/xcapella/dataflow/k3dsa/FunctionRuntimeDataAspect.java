package org.gemoc.xcapella.dataflow.k3dsa;

import com.thalesgroup.trt.mde.vp.modesimulation.ModeSimulation.FunctionRuntimeData;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties;
import org.polarsys.capella.core.data.fa.AbstractFunction;

@Aspect(className = FunctionRuntimeData.class)
@SuppressWarnings("all")
public class FunctionRuntimeDataAspect {
  public static String activate(final FunctionRuntimeData _self) {
    org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_ = org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_activate(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static String start(final FunctionRuntimeData _self) {
    org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_ = org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_start(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static String run(final FunctionRuntimeData _self) {
    org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_ = org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_run(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static String stop(final FunctionRuntimeData _self) {
    org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_ = org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_stop(_self_, _self);
    return (java.lang.String)result;
  }
  
  public static String deactivate(final FunctionRuntimeData _self) {
    org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_ = org.gemoc.xcapella.dataflow.k3dsa.FunctionRuntimeDataAspectFunctionRuntimeDataAspectContext.getSelf(_self);
    Object result = null;
    result =_privk3_deactivate(_self_, _self);
    return (java.lang.String)result;
  }
  
  protected static String _privk3_activate(final FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_, final FunctionRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      AbstractFunction func = ((AbstractFunction) _eContainer);
      boolean _isIsActive = _self.isIsActive();
      if (_isIsActive) {
        String _name = func.getName();
        String _plus = ("ERROR: " + _name);
        String _plus_1 = (_plus + " HAS BEEN ACTIVATED ELSEWHERE!");
        InputOutput.<String>println(_plus_1);
        return "ERROR";
      }
      _self.setIsActive(true);
      String _name_1 = func.getName();
      String _plus_2 = (_name_1 + " ACTIVE!");
      _xblockexpression = InputOutput.<String>println(_plus_2);
    }
    return _xblockexpression;
  }
  
  protected static String _privk3_start(final FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_, final FunctionRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      AbstractFunction func = ((AbstractFunction) _eContainer);
      boolean _isIsStarted = _self.isIsStarted();
      if (_isIsStarted) {
        String _name = func.getName();
        String _plus = ("ERROR: " + _name);
        String _plus_1 = (_plus + " HAS BEEN STARTED ELSEWHERE!");
        InputOutput.<String>println(_plus_1);
        return "ERROR";
      }
      boolean _isIsActive = _self.isIsActive();
      boolean _not = (!_isIsActive);
      if (_not) {
        String _name_1 = func.getName();
        String _plus_2 = ("ERROR: " + _name_1);
        String _plus_3 = (_plus_2 + " MUST BE ACTIVATED BEFORE STARTED!");
        InputOutput.<String>println(_plus_3);
        return "ERROR";
      }
      _self.setIsStarted(true);
      String _name_2 = func.getName();
      String _plus_4 = (_name_2 + " STARTED!");
      _xblockexpression = InputOutput.<String>println(_plus_4);
    }
    return _xblockexpression;
  }
  
  protected static String _privk3_run(final FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_, final FunctionRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      AbstractFunction func = ((AbstractFunction) _eContainer);
      boolean _isIsRunning = _self.isIsRunning();
      if (_isIsRunning) {
        String _name = func.getName();
        String _plus = ("ERROR: " + _name);
        String _plus_1 = (_plus + " HAS BEEN RUNNED ELSEWHERE!");
        InputOutput.<String>println(_plus_1);
        return "ERROR";
      }
      boolean _isIsStarted = _self.isIsStarted();
      boolean _not = (!_isIsStarted);
      if (_not) {
        String _name_1 = func.getName();
        String _plus_2 = ("ERROR: " + _name_1);
        String _plus_3 = (_plus_2 + " MUST BE STARTED BEFORE RUNNED!");
        InputOutput.<String>println(_plus_3);
        return "ERROR";
      }
      _self.setIsRunning(true);
      String _name_2 = func.getName();
      String _plus_4 = (_name_2 + " RUNNING!");
      _xblockexpression = InputOutput.<String>println(_plus_4);
    }
    return _xblockexpression;
  }
  
  protected static String _privk3_stop(final FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_, final FunctionRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      AbstractFunction func = ((AbstractFunction) _eContainer);
      boolean _isIsStarted = _self.isIsStarted();
      boolean _not = (!_isIsStarted);
      if (_not) {
        String _name = func.getName();
        String _plus = ("ERROR: " + _name);
        String _plus_1 = (_plus + " HAS BEEN STOPPED ELSEWHERE!");
        InputOutput.<String>println(_plus_1);
        return "ERROR";
      }
      _self.setIsRunning(false);
      _self.setIsStarted(false);
      String _name_1 = func.getName();
      String _plus_2 = (_name_1 + " STOPPED!");
      _xblockexpression = InputOutput.<String>println(_plus_2);
    }
    return _xblockexpression;
  }
  
  protected static String _privk3_deactivate(final FunctionRuntimeDataAspectFunctionRuntimeDataAspectProperties _self_, final FunctionRuntimeData _self) {
    String _xblockexpression = null;
    {
      EObject _eContainer = _self.eContainer();
      AbstractFunction func = ((AbstractFunction) _eContainer);
      boolean _isIsActive = _self.isIsActive();
      boolean _not = (!_isIsActive);
      if (_not) {
        String _name = func.getName();
        String _plus = ("ERROR: " + _name);
        String _plus_1 = (_plus + " HAS BEEN DEACTIVATED ELSEWHERE!");
        InputOutput.<String>println(_plus_1);
        return "ERROR";
      }
      _self.setIsRunning(false);
      _self.setIsStarted(false);
      _self.setIsActive(false);
      String _name_1 = func.getName();
      String _plus_2 = (_name_1 + " NOT ACTIVE!");
      _xblockexpression = InputOutput.<String>println(_plus_2);
    }
    return _xblockexpression;
  }
}
