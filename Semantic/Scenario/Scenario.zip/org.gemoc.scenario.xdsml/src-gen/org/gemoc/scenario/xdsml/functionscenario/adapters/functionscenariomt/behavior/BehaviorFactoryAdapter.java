package org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.behavior;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory;
import org.polarsys.capella.common.data.behavior.BehaviorFactory;

@SuppressWarnings("all")
public class BehaviorFactoryAdapter extends EFactoryImpl implements org.gemoc.scenario.xdsml.functionscenariomt.behavior.BehaviorFactory {
  private FunctionScenarioMTAdaptersFactory adaptersFactory = org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory.getInstance();
  
  private BehaviorFactory behaviorAdaptee = org.polarsys.capella.common.data.behavior.BehaviorFactory.eINSTANCE;
  
  @Override
  public EPackage getEPackage() {
    return getBehaviorPackage();
  }
  
  public org.gemoc.scenario.xdsml.functionscenariomt.behavior.BehaviorPackage getBehaviorPackage() {
    return org.gemoc.scenario.xdsml.functionscenariomt.behavior.BehaviorPackage.eINSTANCE;
  }
}
