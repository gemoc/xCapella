package org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.capellamodeller;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory;
import org.polarsys.capella.core.data.capellamodeller.CapellamodellerFactory;

@SuppressWarnings("all")
public class CapellamodellerFactoryAdapter extends EFactoryImpl implements org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.CapellamodellerFactory {
  private FunctionScenarioMTAdaptersFactory adaptersFactory = org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory.getInstance();
  
  private CapellamodellerFactory capellamodellerAdaptee = org.polarsys.capella.core.data.capellamodeller.CapellamodellerFactory.eINSTANCE;
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.Project createProject() {
    return adaptersFactory.createProjectAdapter(capellamodellerAdaptee.createProject(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.Folder createFolder() {
    return adaptersFactory.createFolderAdapter(capellamodellerAdaptee.createFolder(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.SystemEngineering createSystemEngineering() {
    return adaptersFactory.createSystemEngineeringAdapter(capellamodellerAdaptee.createSystemEngineering(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.SystemEngineeringPkg createSystemEngineeringPkg() {
    return adaptersFactory.createSystemEngineeringPkgAdapter(capellamodellerAdaptee.createSystemEngineeringPkg(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.Library createLibrary() {
    return adaptersFactory.createLibraryAdapter(capellamodellerAdaptee.createLibrary(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getCapellamodellerPackage();
  }
  
  public org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.CapellamodellerPackage getCapellamodellerPackage() {
    return org.gemoc.scenario.xdsml.functionscenariomt.capellamodeller.CapellamodellerPackage.eINSTANCE;
  }
}
