package org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.information.communication;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory;
import org.polarsys.capella.core.data.information.communication.CommunicationFactory;

@SuppressWarnings("all")
public class CommunicationFactoryAdapter extends EFactoryImpl implements org.gemoc.scenario.xdsml.functionscenariomt.communication.CommunicationFactory {
  private FunctionScenarioMTAdaptersFactory adaptersFactory = org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory.getInstance();
  
  private CommunicationFactory communicationAdaptee = org.polarsys.capella.core.data.information.communication.CommunicationFactory.eINSTANCE;
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.Exception createException() {
    return adaptersFactory.createExceptionAdapter(communicationAdaptee.createException(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.Message createMessage() {
    return adaptersFactory.createMessageAdapter(communicationAdaptee.createMessage(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.MessageReference createMessageReference() {
    return adaptersFactory.createMessageReferenceAdapter(communicationAdaptee.createMessageReference(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.Signal createSignal() {
    return adaptersFactory.createSignalAdapter(communicationAdaptee.createSignal(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.SignalInstance createSignalInstance() {
    return adaptersFactory.createSignalInstanceAdapter(communicationAdaptee.createSignalInstance(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.CommunicationLink createCommunicationLink() {
    return adaptersFactory.createCommunicationLinkAdapter(communicationAdaptee.createCommunicationLink(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.CommunicationLinkAllocation createCommunicationLinkAllocation() {
    return adaptersFactory.createCommunicationLinkAllocationAdapter(communicationAdaptee.createCommunicationLinkAllocation(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getCommunicationPackage();
  }
  
  public org.gemoc.scenario.xdsml.functionscenariomt.communication.CommunicationPackage getCommunicationPackage() {
    return org.gemoc.scenario.xdsml.functionscenariomt.communication.CommunicationPackage.eINSTANCE;
  }
}
