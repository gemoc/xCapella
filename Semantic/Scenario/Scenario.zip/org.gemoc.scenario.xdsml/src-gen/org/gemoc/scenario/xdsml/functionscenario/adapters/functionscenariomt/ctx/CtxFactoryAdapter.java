package org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.ctx;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory;
import org.polarsys.capella.core.data.ctx.CtxFactory;

@SuppressWarnings("all")
public class CtxFactoryAdapter extends EFactoryImpl implements org.gemoc.scenario.xdsml.functionscenariomt.ctx.CtxFactory {
  private FunctionScenarioMTAdaptersFactory adaptersFactory = org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory.getInstance();
  
  private CtxFactory ctxAdaptee = org.polarsys.capella.core.data.ctx.CtxFactory.eINSTANCE;
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemAnalysis createSystemAnalysis() {
    return adaptersFactory.createSystemAnalysisAdapter(ctxAdaptee.createSystemAnalysis(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.System createSystem() {
    return adaptersFactory.createSystemAdapter(ctxAdaptee.createSystem(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemFunction createSystemFunction() {
    return adaptersFactory.createSystemFunctionAdapter(ctxAdaptee.createSystemFunction(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemFunctionPkg createSystemFunctionPkg() {
    return adaptersFactory.createSystemFunctionPkgAdapter(ctxAdaptee.createSystemFunctionPkg(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemCommunicationHook createSystemCommunicationHook() {
    return adaptersFactory.createSystemCommunicationHookAdapter(ctxAdaptee.createSystemCommunicationHook(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemCommunication createSystemCommunication() {
    return adaptersFactory.createSystemCommunicationAdapter(ctxAdaptee.createSystemCommunication(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.Actor createActor() {
    return adaptersFactory.createActorAdapter(ctxAdaptee.createActor(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.ActorCapabilityInvolvement createActorCapabilityInvolvement() {
    return adaptersFactory.createActorCapabilityInvolvementAdapter(ctxAdaptee.createActorCapabilityInvolvement(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.ActorMissionInvolvement createActorMissionInvolvement() {
    return adaptersFactory.createActorMissionInvolvementAdapter(ctxAdaptee.createActorMissionInvolvement(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.ActorPkg createActorPkg() {
    return adaptersFactory.createActorPkgAdapter(ctxAdaptee.createActorPkg(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.Mission createMission() {
    return adaptersFactory.createMissionAdapter(ctxAdaptee.createMission(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.MissionPkg createMissionPkg() {
    return adaptersFactory.createMissionPkgAdapter(ctxAdaptee.createMissionPkg(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemMissionInvolvement createSystemMissionInvolvement() {
    return adaptersFactory.createSystemMissionInvolvementAdapter(ctxAdaptee.createSystemMissionInvolvement(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.Capability createCapability() {
    return adaptersFactory.createCapabilityAdapter(ctxAdaptee.createCapability(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.CapabilityExploitation createCapabilityExploitation() {
    return adaptersFactory.createCapabilityExploitationAdapter(ctxAdaptee.createCapabilityExploitation(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.CapabilityPkg createCapabilityPkg() {
    return adaptersFactory.createCapabilityPkgAdapter(ctxAdaptee.createCapabilityPkg(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemCapabilityInvolvement createSystemCapabilityInvolvement() {
    return adaptersFactory.createSystemCapabilityInvolvementAdapter(ctxAdaptee.createSystemCapabilityInvolvement(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.OperationalActorRealization createOperationalActorRealization() {
    return adaptersFactory.createOperationalActorRealizationAdapter(ctxAdaptee.createOperationalActorRealization(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.OperationalAnalysisRealization createOperationalAnalysisRealization() {
    return adaptersFactory.createOperationalAnalysisRealizationAdapter(ctxAdaptee.createOperationalAnalysisRealization(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.OperationalEntityRealization createOperationalEntityRealization() {
    return adaptersFactory.createOperationalEntityRealizationAdapter(ctxAdaptee.createOperationalEntityRealization(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.SystemContext createSystemContext() {
    return adaptersFactory.createSystemContextAdapter(ctxAdaptee.createSystemContext(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getCtxPackage();
  }
  
  public org.gemoc.scenario.xdsml.functionscenariomt.ctx.CtxPackage getCtxPackage() {
    return org.gemoc.scenario.xdsml.functionscenariomt.ctx.CtxPackage.eINSTANCE;
  }
}
