package org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.information.datavalue;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EFactoryImpl;
import org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory;
import org.polarsys.capella.core.data.information.datavalue.DatavalueFactory;

@SuppressWarnings("all")
public class DatavalueFactoryAdapter extends EFactoryImpl implements org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.DatavalueFactory {
  private FunctionScenarioMTAdaptersFactory adaptersFactory = org.gemoc.scenario.xdsml.functionscenario.adapters.functionscenariomt.FunctionScenarioMTAdaptersFactory.getInstance();
  
  private DatavalueFactory datavalueAdaptee = org.polarsys.capella.core.data.information.datavalue.DatavalueFactory.eINSTANCE;
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.LiteralBooleanValue createLiteralBooleanValue() {
    return adaptersFactory.createLiteralBooleanValueAdapter(datavalueAdaptee.createLiteralBooleanValue(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.BooleanReference createBooleanReference() {
    return adaptersFactory.createBooleanReferenceAdapter(datavalueAdaptee.createBooleanReference(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.EnumerationLiteral createEnumerationLiteral() {
    return adaptersFactory.createEnumerationLiteralAdapter(datavalueAdaptee.createEnumerationLiteral(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.EnumerationReference createEnumerationReference() {
    return adaptersFactory.createEnumerationReferenceAdapter(datavalueAdaptee.createEnumerationReference(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.LiteralStringValue createLiteralStringValue() {
    return adaptersFactory.createLiteralStringValueAdapter(datavalueAdaptee.createLiteralStringValue(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.StringReference createStringReference() {
    return adaptersFactory.createStringReferenceAdapter(datavalueAdaptee.createStringReference(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.LiteralNumericValue createLiteralNumericValue() {
    return adaptersFactory.createLiteralNumericValueAdapter(datavalueAdaptee.createLiteralNumericValue(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.NumericReference createNumericReference() {
    return adaptersFactory.createNumericReferenceAdapter(datavalueAdaptee.createNumericReference(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.ComplexValue createComplexValue() {
    return adaptersFactory.createComplexValueAdapter(datavalueAdaptee.createComplexValue(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.ComplexValueReference createComplexValueReference() {
    return adaptersFactory.createComplexValueReferenceAdapter(datavalueAdaptee.createComplexValueReference(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.ValuePart createValuePart() {
    return adaptersFactory.createValuePartAdapter(datavalueAdaptee.createValuePart(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.BinaryExpression createBinaryExpression() {
    return adaptersFactory.createBinaryExpressionAdapter(datavalueAdaptee.createBinaryExpression(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.UnaryExpression createUnaryExpression() {
    return adaptersFactory.createUnaryExpressionAdapter(datavalueAdaptee.createUnaryExpression(), null);
  }
  
  @Override
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.OpaqueExpression createOpaqueExpression() {
    return adaptersFactory.createOpaqueExpressionAdapter(datavalueAdaptee.createOpaqueExpression(), null);
  }
  
  @Override
  public EPackage getEPackage() {
    return getDatavaluePackage();
  }
  
  public org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.DatavaluePackage getDatavaluePackage() {
    return org.gemoc.scenario.xdsml.functionscenariomt.information.datavalue.DatavaluePackage.eINSTANCE;
  }
}
