package org.gemoc.scenario.k3dsa;

@SuppressWarnings("all")
public class SystemFunctionAspectSystemFunctionAspectProperties {
  public boolean isStarted = false;
  
  public boolean isReady = false;
  
  public boolean isSuspended = false;
  
  public boolean isStopped = false;
  
  public int runCycles = 0;
}
