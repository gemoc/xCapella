package org.gemoc.scenario.k3dsa;

import com.google.common.base.Objects;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties;
import org.polarsys.capella.core.data.ctx.SystemFunction;

@Aspect(className = SystemFunction.class)
@SuppressWarnings("all")
public class SystemFunctionAspect {
  public static Boolean hasUnnamedLabel(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_hasUnnamedLabel(_self_, _self);;
    return (java.lang.Boolean)result;
  }
  
  public static String getLabel(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_getLabel(_self_, _self);;
    return (java.lang.String)result;
  }
  
  public static String getFullLabel(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_getFullLabel(_self_, _self);;
    return (java.lang.String)result;
  }
  
  public static String destroy(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_destroy(_self_, _self);;
    return (java.lang.String)result;
  }
  
  private static boolean isStarted(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_isStarted(_self_, _self);;
    return (boolean)result;
  }
  
  private static void isStarted(final SystemFunction _self, final boolean isStarted) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    _privk3_isStarted(_self_, _self,isStarted);;
  }
  
  private static boolean isReady(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_isReady(_self_, _self);;
    return (boolean)result;
  }
  
  private static void isReady(final SystemFunction _self, final boolean isReady) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    _privk3_isReady(_self_, _self,isReady);;
  }
  
  private static boolean isSuspended(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_isSuspended(_self_, _self);;
    return (boolean)result;
  }
  
  private static void isSuspended(final SystemFunction _self, final boolean isSuspended) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    _privk3_isSuspended(_self_, _self,isSuspended);;
  }
  
  private static boolean isStopped(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_isStopped(_self_, _self);;
    return (boolean)result;
  }
  
  private static void isStopped(final SystemFunction _self, final boolean isStopped) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    _privk3_isStopped(_self_, _self,isStopped);;
  }
  
  private static int runCycles(final SystemFunction _self) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    Object result = null;
    result = _privk3_runCycles(_self_, _self);;
    return (int)result;
  }
  
  private static void runCycles(final SystemFunction _self, final int runCycles) {
    final org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectProperties _self_ = org.gemoc.scenario.k3dsa.SystemFunctionAspectSystemFunctionAspectContext.getSelf(_self);
    _privk3_runCycles(_self_, _self,runCycles);;
  }
  
  protected static Boolean _privk3_hasUnnamedLabel(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    boolean _and = false;
    boolean _isStarted = SystemFunctionAspect.isStarted(_self);
    if (!_isStarted) {
      _and = false;
    } else {
      boolean _isSuspended = SystemFunctionAspect.isSuspended(_self);
      boolean _not = (!_isSuspended);
      _and = _not;
    }
    if (_and) {
      String _name = _self.getName();
      String _plus = (_name + " is STOPPED");
      InputOutput.<String>println(_plus);
      SystemFunctionAspect.isStarted(_self, false);
      SystemFunctionAspect.isReady(_self, false);
      SystemFunctionAspect.isSuspended(_self, false);
      SystemFunctionAspect.isStopped(_self, true);
      SystemFunctionAspect.runCycles(_self, 0);
      _self.setReview("   ");
    } else {
      String _name_1 = _self.getName();
      String _plus_1 = (_name_1 + " is STARTED");
      InputOutput.<String>println(_plus_1);
      SystemFunctionAspect.isStarted(_self, true);
      boolean _and_1 = false;
      String _review = _self.getReview();
      boolean _notEquals = (!Objects.equal(_review, null));
      if (!_notEquals) {
        _and_1 = false;
      } else {
        boolean _isSuspended_1 = SystemFunctionAspect.isSuspended(_self);
        boolean _not_1 = (!_isSuspended_1);
        _and_1 = _not_1;
      }
      if (_and_1) {
        _self.setReview(" started");
      }
    }
    return Boolean.valueOf(false);
  }
  
  protected static String _privk3_getLabel(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    boolean _isReady = SystemFunctionAspect.isReady(_self);
    boolean _equals = (_isReady == false);
    if (_equals) {
      String _name = _self.getName();
      String _plus = (_name + " is activated");
      InputOutput.<String>println(_plus);
      String _review = _self.getReview();
      boolean _equals_1 = Objects.equal(_review, null);
      if (_equals_1) {
        _self.setReview(" activated");
      } else {
        String _review_1 = _self.getReview();
        int _length = _review_1.length();
        boolean _lessEqualsThan = (_length <= 3);
        if (_lessEqualsThan) {
          _self.setReview(" activated");
        }
      }
      SystemFunctionAspect.isReady(_self, true);
    } else {
      int _runCycles = SystemFunctionAspect.runCycles(_self);
      int _plus_1 = (_runCycles + 1);
      SystemFunctionAspect.runCycles(_self, _plus_1);
      String _name_1 = _self.getName();
      String _plus_2 = (_name_1 + " ran for ");
      int _runCycles_1 = SystemFunctionAspect.runCycles(_self);
      String _plus_3 = (_plus_2 + Integer.valueOf(_runCycles_1));
      String _plus_4 = (_plus_3 + " cycles");
      InputOutput.<String>println(_plus_4);
      int _runCycles_2 = SystemFunctionAspect.runCycles(_self);
      String _string = Integer.valueOf(_runCycles_2).toString();
      _self.setDescription(_string);
    }
    return _self.getName();
  }
  
  protected static String _privk3_getFullLabel(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    SystemFunctionAspect.isSuspended(_self, true);
    String _name = _self.getName();
    String _plus = (_name + " is suspended");
    InputOutput.<String>println(_plus);
    _self.setReview(" suspended");
    return _self.getName();
  }
  
  protected static String _privk3_destroy(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    SystemFunctionAspect.isSuspended(_self, false);
    String _name = _self.getName();
    String _plus = (_name + " is resumed");
    InputOutput.<String>println(_plus);
    String _review = _self.getReview();
    String _replaceAll = _review.replaceAll(" suspended", "");
    _self.setReview(_replaceAll);
    return _self.getName();
  }
  
  protected static boolean _privk3_isStarted(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getIsStarted") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (boolean) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.isStarted;
  }
  
  protected static void _privk3_isStarted(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self, final boolean isStarted) {
    _self_.isStarted = isStarted; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setIsStarted")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, isStarted);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
  
  protected static boolean _privk3_isReady(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getIsReady") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (boolean) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.isReady;
  }
  
  protected static void _privk3_isReady(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self, final boolean isReady) {
    _self_.isReady = isReady; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setIsReady")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, isReady);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
  
  protected static boolean _privk3_isSuspended(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getIsSuspended") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (boolean) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.isSuspended;
  }
  
  protected static void _privk3_isSuspended(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self, final boolean isSuspended) {
    _self_.isSuspended = isSuspended; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setIsSuspended")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, isSuspended);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
  
  protected static boolean _privk3_isStopped(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getIsStopped") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (boolean) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.isStopped;
  }
  
  protected static void _privk3_isStopped(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self, final boolean isStopped) {
    _self_.isStopped = isStopped; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setIsStopped")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, isStopped);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
  
  protected static int _privk3_runCycles(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getRunCycles") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (int) ret;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.runCycles;
  }
  
  protected static void _privk3_runCycles(final SystemFunctionAspectSystemFunctionAspectProperties _self_, final SystemFunction _self, final int runCycles) {
    _self_.runCycles = runCycles; try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setRunCycles")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, runCycles);
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
  }
}
