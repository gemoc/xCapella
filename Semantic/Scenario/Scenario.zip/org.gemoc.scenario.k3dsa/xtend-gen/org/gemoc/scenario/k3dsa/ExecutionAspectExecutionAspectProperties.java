package org.gemoc.scenario.k3dsa;

@SuppressWarnings("all")
public class ExecutionAspectExecutionAspectProperties {
}
