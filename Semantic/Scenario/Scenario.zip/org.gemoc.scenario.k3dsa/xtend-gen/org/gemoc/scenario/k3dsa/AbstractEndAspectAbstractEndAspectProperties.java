package org.gemoc.scenario.k3dsa;

@SuppressWarnings("all")
public class AbstractEndAspectAbstractEndAspectProperties {
  public int occ = 0;
}
